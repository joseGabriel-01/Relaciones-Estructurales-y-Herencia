package model;

public class W {
    protected W w; // Asociación reflexiva con multiplicidad 1

    public W() {
        this.w = null;
    }

    public W(W w) {
        this.w = w;
    }

    public boolean w1() {
        return true;
    }

    public W getW() {
        return w;
    }

    public void setW(W w) {
        this.w = w;
    }
}