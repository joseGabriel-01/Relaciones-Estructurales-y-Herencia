package model;

public class X extends W implements Z {
    private A a; // Asociación con A

    public X(A a, W w) {
        super(w);
        this.a = a;
    }

    @Override
    public boolean w1() {
        return false;
    }

    @Override
    public int z1() {
        return 42;
    }

    @Override
    public float z2(boolean b) {
        return b ? 3.14f : 0.0f;
    }

    public A getA() {
        return a;
    }

    public void setA(A a) {
        this.a = a;
    }

    @Override
    public String toString() {
        return "X{a=" + a + ", w=" + w + "}";
    }
}