package model;

import org.junit.Assert;
import org.junit.Test;

public class XTest {

    @Test
    public void testZ1() {
        A a = new A(1);
        X x = new X(a, null);
        Assert.assertEquals(42, x.z1());
    }

    @Test
    public void testZ2() {
        A a = new A(1);
        X x = new X(a, null);
        Assert.assertEquals(3.14f, x.z2(true), 0.001f);
        Assert.assertEquals(0.0f, x.z2(false), 0.001f);
    }

    @Test
    public void testW1() {
        A a = new A(1);
        W wParent = new W();
        X x = new X(a, wParent);
        Assert.assertFalse(x.w1());
        Assert.assertNotNull(x.getW());
    }

    @Test
    public void testToString() {
        A a = new A(5);
        X x = new X(a, null);
        String resultado = x.toString();
        Assert.assertTrue(resultado.contains("A{id=5}"));
    }
}